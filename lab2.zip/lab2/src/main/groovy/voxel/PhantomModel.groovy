package voxel

class PhantomModel extends Model {

	private HeatPoint[] heatPoints;

    PhantomModel(float minX, float minY, float minZ, float incX,
                      float incY, float incZ, float[][] points) {

		super(minX, minY, minZ, incX, incY, incZ);

		resX = resY = resZ = 256;
		
		this.heatPoints = new HeatPoint[points.length];
		for (int n = 0; n < points.length; n++) {
			heatPoints[n] = new HeatPoint(points[n]);
		}
	}

	private float distance(float x1, float y1, float z1, 
						   float x2, float y2, float z2) {

		float d = 0.0f;
		
		//TODO: IMPLEMENT THIS
		
		d
	}

	private int contribution(float x, float y, float z, int p) {

		int v = 0;
		HeatPoint h = heatPoints[p];

		float d = distance(x, y, z, h.x, h.y, h.z);
		
		//TODO: IMPLEMENT THIS
		
		v
	}

	void createVoxelModel() {

		voxels = new int[resX][resY][resZ];

		//TODO: IMPLEMENT THIS
	}

	
	class HeatPoint {
		
		private float x, y, z, radius, value;

		HeatPoint(float[] floats) {
			
			x = floats[0];
			y = floats[1];
			z = floats[2];
			radius = floats[3];
			value = floats[4];
		}
	}

}
